var darkmode = true; // Toggle dark mode
var date = true; // Show date
var twelvehour = true;
var battery = false; // Toggle battery view (requires InfoStats)
var wifi = true;
var blur = false;
